let slideIndex = 0;
const slides = document.getElementsByClassName('modal-slide');
let touchStartX = 0;

function openModal(index) {
    document.getElementById('imageModal').style.display = 'flex';
    slideIndex = index;
    showSlides(slideIndex);
    document.addEventListener('touchstart', handleTouchStart, false);
    document.addEventListener('touchmove', handleTouchMove, false);
    document.addEventListener('click', handleClickOutside, false); // Add this line
}

function closeModal() {
    document.getElementById('imageModal').style.display = 'none';
    document.removeEventListener('touchstart', handleTouchStart, false);
    document.removeEventListener('touchmove', handleTouchMove, false);
    document.removeEventListener('click', handleClickOutside, false); // Add this line
}

function changeSlide(n) {
    slideIndex += n;
    showSlides(slideIndex);
}

function showSlides(n) {
    if (n >= slides.length) { slideIndex = 0 }
    if (n < 0) { slideIndex = slides.length - 1 }
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = 'none';
    }
    slides[slideIndex].style.display = 'block';
}

function handleTouchStart(event) {
    touchStartX = event.touches[0].clientX;
}

function handleTouchMove(event) {
    const touchEndX = event.touches[0].clientX;
    const swipeThreshold = 70; // Adjust this value as needed
    if (touchEndX - touchStartX > swipeThreshold) {
        changeSlide(-1); // Swipe left
    } else if (touchStartX - touchEndX > swipeThreshold) {
        changeSlide(1); // Swipe right
    }
}

function handleClickOutside(event) {
    const modal = document.getElementById('imageModal');
    if (event.target === modal) {
        closeModal();
    }
}
