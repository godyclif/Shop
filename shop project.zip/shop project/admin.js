document.getElementById('admin-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData();
    formData.append('product-id', document.getElementById('product-id').value);
    formData.append('product-info', document.getElementById('product-info').value);
    formData.append('product-price', document.getElementById('product-price').value);
    formData.append('product-gender', document.getElementById('product-gender').value);
    formData.append('product-age', document.getElementById('product-age').value);
    formData.append('product-how-old', document.getElementById('product-how-old').value);
    formData.append('product-description', document.getElementById('product-description').value);

    const images = document.getElementById('product-images').files;
    for (let i = 0; i < images.length; i++) {
        formData.append('product-images[]', images[i]);
    }

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'api/add_product.php', true);

    xhr.upload.onprogress = function(event) {
        if (event.lengthComputable) {
            const percentComplete = (event.loaded / event.total) * 100;
            const progressBar = document.getElementById('progress-bar');
            progressBar.style.width = percentComplete + '%';
        }
    };

    xhr.onloadstart = function() {
        document.getElementById('progress-container').style.display = 'block';
    };

    xhr.onloadend = function() {
        document.getElementById('progress-container').style.display = 'none';
    };

    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            const response = JSON.parse(xhr.responseText);
            alert(response.message);
        }
    };

    xhr.send(formData);
});