<?php
$servername = "localhost";
$username = "pxxlspac_shortest_user";
$password = "uxwSsgMgYa";
$dbname = "pxxlspac_shortest_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$unique_product_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$unique_product_id) {
    echo json_encode(["error" => "No product ID provided"]);
    exit();
}

$sql = "SELECT * FROM unique_products WHERE id = '$unique_product_id'";
$result = $conn->query($sql);

if ($result === false) {
    echo json_encode(["error" => "SQL error: " . $conn->error]);
    exit();
}

if ($result->num_rows > 0) {
    $unique_product = $result->fetch_assoc();
    $unique_product['unique_images'] = json_decode($unique_product['unique_images']);
    $unique_product['unique_details'] = json_decode($unique_product['unique_details']);
    echo json_encode($unique_product);
} else {
    echo json_encode(["error" => "No product found with the given ID"]);
}

$conn->close();
?>