<?php
$servername = "localhost";
$username = "pxxlspac_shortest_user";
$password = "uxwSsgMgYa";
$dbname = "pxxlspac_shortest_db";

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$product_id = $_POST['product-id'];
$product_info = $_POST['product-info'];
$product_price = $_POST['product-price'];
$product_gender = $_POST['product-gender'];
$product_age = $_POST['product-age'];
$product_how_old = $_POST['product-how-old'];
$product_description = $_POST['product-description'];
$product_images = [];

$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Check for errors in file upload
if (isset($_FILES['product-images'])) {
    foreach ($_FILES['product-images']['error'] as $key => $error) {
        if ($error != UPLOAD_ERR_OK) {
            echo json_encode(['status' => 'error', 'message' => 'Error uploading file: ' . $error]);
            exit();
        }
    }

    foreach ($_FILES['product-images']['name'] as $key => $image_name) {
        $image_tmp_name = $_FILES['product-images']['tmp_name'][$key];
        $image_path = $upload_dir . basename($image_name);
        if (move_uploaded_file($image_tmp_name, $image_path)) {
            $product_images[] = $image_path;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to move uploaded file: ' . $image_name]);
            exit();
        }
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No files uploaded.']);
    exit();
}

$product_images_json = json_encode($product_images);

$sql = "INSERT INTO products (id, info, price, gender, age, how_old, description, images)
        VALUES ('$product_id', '$product_info', '$product_price', '$product_gender', '$product_age', '$product_how_old', '$product_description', '$product_images_json')
        ON DUPLICATE KEY UPDATE info='$product_info', price='$product_price', gender='$product_gender', age='$product_age', how_old='$product_how_old', description='$product_description', images='$product_images_json'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['status' => 'success', 'message' => 'Product added/edited successfully!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
}

$conn->close();
?>