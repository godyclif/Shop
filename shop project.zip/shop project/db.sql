USE pxxlspac_shortest_db;

CREATE TABLE products (
    id VARCHAR(255) PRIMARY KEY,
    info TEXT,
    price DECIMAL(10, 2),
    images TEXT,
    gender VARCHAR(255),
    age VARCHAR(255),
    how_old VARCHAR(255),
    description TEXT,
    details TEXT
);
